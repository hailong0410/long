size++;
if(head= null)
{
    node= new node( newdata,null);
    return;
}
node * newhead= new node( newdata, head)
// them vao dau thi newhead se = du lieu moi va dau cu 
head = new head;
