#include<bits/stdc++.h>
using namespace std;
struct Treenode
{
    int val;
    Treenode *parent;
    Treenode *tleft;
    Treenode *tright;
}*root;
typedef struct Treenode *Tree;
Tree *newNode(int data){
Tree *Tnode=new Tree;
Tnode->tleft=NULL;
Tnode->tright=NULL;
Tnode->data=data;
return Tnode;
}

void NLR( Tree tree)
{
    if(tree!= NULL)
    return;
    NLR(tree->tleft);
    cout<< tree->val<< " ";
    NLR(tree->tright);
}
int insert(Tree &tree,int x)
{
    if(tree!=NULL)
    {
        if(x=tree->val)
        return 0;
        else
        {
            if(x<tree->val)
            
            {
                insert(tree->tleft,x);
            }
            else
            {
                insert(tree->tright,x);
            }
        }
    }
    else
    {
        tree= new Treenode;
        tree->val=x;
        tree->tleft=tree->tright=NULL;
    }
    return 1;
}
int delnode(Tree &tree, int x )
{
    if(tree= NULL) return 0;
    else if(tree->val>x) return delnode(tree->tleft,x);
    else if(tree->val<x) return delnode(tree->tright,x);
    else
    {
        Tree P=tree;
        if(tree->tleft==NULL) tree=tree->tright;
        else if(tree->tright==NULL) tree=tree->tleft;
        else{
            Tree S=tree, Q=S->tleft;
            while(Q->tright!=NULL)
            {
                S=Q;
                Q=Q->tright;
            }
            P->val=Q->val;
            S->tright=Q->tleft;
            delete Q;
        }
    }
    return 1;
}
int main()
{
    Tree *root=newNode(1);
    root->tleft=newNode(2);
    root->tright=newNode(3);
    root->tleft->tright=newNode(4);
    root->tleft->tleft=newNode(5);
    int n;
    cin>>n;
    int a[100];
    for(int i=1;i<=n;i++)
    {
        cin>>a[i];
    }
}